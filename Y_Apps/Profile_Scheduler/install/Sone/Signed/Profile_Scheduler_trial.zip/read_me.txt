This application does not support back upping.

This application is used for scheduling profiles with timer, to make a new schedule, select new menu options from the options menu.

Then select the profile to be scheduled. Note that if the random profiles list is empty, the whole schedule will be ignored by the scheduler. 
After selecting the profile, then select time and repeat options for the schedule. Once done, save the schedule with save command.

After the schedule is made it will be shown in the main view list. Within this list you can use menu options for opening the schedule for modifications 
as well as you can delete them, also temporal disabling/enabling menu options can be found from the options menu.

Note that profiles are scheduled as well as previous schedules are re-freshed only after exiting the application. For best usability, 
each schedule should be spaced two minutes apart from each other. 

The actual scheduling is handled by background application that is also automatically started when the device is started. 

No message scheduling will appear while the device is off.


 

