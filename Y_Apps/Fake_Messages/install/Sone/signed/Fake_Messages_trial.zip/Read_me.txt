This application does not support back upping.

This application is used for faking incoming SMS messages, fake messages can be scheduled to be made in the future time, 
or if past time is set for the message it will be made immediate after exiting the application with the past timestamp on it.

To make a new message, click new from the options menu, set the sender name and number (or get them from contacts with menu options), 
write the message (or use previously saved messages with menu options), 
set the sending time and date and select save menu option to save the message into the database.

After the message is made it will be shown in the main view list. 
Within this list you can use menu options for opening the message for modifications as well as you can delete them.

Note that messages are scheduled as well as previous schedules are re-freshed only after exiting the application. 
The actual scheduling is handled by background application that is also automatically started when the device is started. 
No message scheduling will appear while the device is off.
