
Note that this application does not support back upping.


This application is inclinometer application that shows the horizontal and vertical device tilt angle, 
and illustrates an image of a car with the measured angle. The application works only in portrait orientation.


The menu option reset allows resetting the tilt angle values to some other device tilt than default, 
so you can first put the device into a holder and then reset the tilt values to zero.

Lights on option allows the device backlight to stay on all of the time, note that this option will consume more battery, 
while allowing the screen to be more readable in dark conditions.
