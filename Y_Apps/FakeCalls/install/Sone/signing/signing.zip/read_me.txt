This application does not support back upping.


This application is used for making Fake incoming calls, no actual calls is made thus there is no charges involved with the Fake calls.

There are four pre-defined keys that can be used for starting the fake call with one button press. These keys are Green phone key, Red phone key, Camera key, and the On/Off button. Note that the keys will only start Fake call when the device key lock is on. 

To set a contact for the keys, select the modify option from the menu. Enable/Disable menu options can be used for enabling/disabling the fake call for the key.

Timed Fake call schedules can be made by selecting New option from the menu, these schedules can be later modified with Modify menu option and delete option can be used for removing the schedule.

Preview call menu option can be used for previewing the Fake call for selected item in the list.

The actual scheduling of the Fake calls is handled by background server that is running if there is any fake call key or fake call schedule available that is also enabled. The background application is also started automatically when device is started. Note that all settings and schedule changes are taking effect only after exiting the UI application.

With timer scheduled Fake calls, you only need to define the contact number (or string) and the time when the Fake call is to be made.

You can select the contact from the device's contacts list, and then also the contacts name will be used in the main schedule list. Note that, if the Fake call number is found from the device's contacts, all information including name, image, ringtone etc. will be used when the Fake call is shown.

The menu option New number also allows using any text string for the Fake call display.

The time for schedule can be selected with time settings item, the Repeat settings item allows the scheduling to be done on selected day on as repeating Fake call with specified repeat interval. Note that repeated Schedules are not deleted from the schedule list, whereas the Fake call schedules specified for a specific date only, will be deleted from the scheduling database after the Fake call is shown.

With single key Fake calls, you only need to define the contact number (or string) for the fake call. You can select the contact from the contacts database or use the menu option New number also allows using any text string for the Fake call display.


Note that, if the Fake call number is found from the device's contacts, all information including name, image, ringtone etc. will be used when the Fake call is shown.

Do remember also to Enable the key fake call from the main schedule list, and note that single-key Fake calls do only work when the device key lock is activated.

The Operator name is used in the upper part of the Fake call screen in cases that the real network name can not be retrieved. For example this will happen when offline profile is in use.

Fallback ringtone is used in cases that the selected contact does not have ringtone, and no profile ringtone can be found. The actual ringtone selection works in a way that if the selected contact has own ringtone, it will be used, and if it does not have, the current profile ringtone will be used, and if the current profile does not have a ringtone, then the fallback ringtone will be used.

Snooze time is snooze time value in seconds used with the Snooze button in Fake call display. When the Snooze button is pressed the fake call display will be hidden, and the display is shown again after the specified snooze time.

Max ringing time defines on how long the Fake call display will be shown after it started. Note that pressing snooze will reset the timer

The Snooze button text setting can be used for changing the text shown in the snooze button for more authentic Fake call display.


