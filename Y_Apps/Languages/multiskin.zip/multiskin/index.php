<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">
<html>

<head>

	<meta name="keywords" content="mobile, joomla, mobilejoomla, online simulator"/>
	<meta name="description" content="An online simulator for MobileJoomla!"/>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />

	<title>Mobile Joomla! Online Simulator</title>

	<link rel="stylesheet" type="text/css" href="css/main.css" />
	<link rel="stylesheet" type="text/css" href="css/preview.css" />
	
	<script type="text/javascript" src="js/mootools.js"></script>
	<script type="text/javascript" src="js/browser.js"></script>

</head>

<body onload="init()">

<div id="page">

	<div id="preview">
		<div id="preview_nokia5800" class="preview">
			<iframe id="preview_nokia5800_frame">
	
			</iframe>
		</div>
		
		<div id="preview_nokian95" class="preview" style="display: none;">
			<iframe id="preview_nokian95_frame">
	
			</iframe>
		</div>
		
		<div id="preview_iphone" class="preview" style="display: none;">
			<iframe id="preview_iphone_frame">
	
			</iframe>
		</div>
		
		<div id="preview_htcg1" class="preview" style="display: none;">
			<iframe id="preview_htcg1_frame">
	
			</iframe>
		</div>
	</div>

	<div id="header">
		
	</div>
	
	<div id="content">
		<p>
		<a href="http://mobilejoomla.com/">Kuneri Mobile Joomla!</a> is the most advanced tool to turn your Joomla! web site 
		into a mobile web site, compatible with all phones in the world, 
		including iPhone, Smartphone, iMode and WAP phones.
		</p>
		<p>
		<a href="http://www.jappit.com/m/mobilejoomla/">Mobile Joomla! Online Simulator</a> allows you to preview how a Mobile Joomla!-powered web site 
		appears on different mobile devices.
		</p>
		<p>
		<strong>Note:</strong> due to the different characteristics of mobile devices, 
		<a href="http://www.jappit.com/m/mobilejoomla/">Mobile Joomla! Online Simulator</a> does not reproduce the exact result you would 
		have on real devices. So, some differences may occur when testing the web site on a real mobile phone.
		</p>
		<p>Please refer to the <a href="http://mobilejoomla.com/wiki/">Mobile Joomla! Wiki</a> for more details</p>
		
		
		<div id="components">

<?

$devices = array(
	'nokia5800', 'nokian95', 'iphone', 'htcg1'
);

$deviceNames = array(
	'Nokia 5800XM', 'Nokia N95 8GB', 'iPhone', 'HTC Dream'
);

$res = '';

for($i = 0; $i < count($devices); $i++)
{
	$res .= '<a href="proxy.php?d=' . $devices[$i] . '" onclick="viewPreview(\'' . $devices[$i] . '\');return false;">' . 
		'<img src="images/thumbs/' . $devices[$i] . '.png" />' . 
		$deviceNames[$i] . 
		'</a>';
}

echo $res;

?>
		
		<div class="clearer"></div>
	
	</div>
	
	<div id="footer">
		&copy; <a href="http://www.forum.nokia.com">MobileJoomla.com</a> - 
		&copy; <a href="http://www.jappit.com">Jappit.com</a>
	</div>

</div>


<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
	</script>
	<script type="text/javascript">
	_uacct = "UA-298789-6";
	urchinTracker();
	</script>

</body>
</html>