var devices = new Array(
	
);

var shownDevice = 'nokia5800';

function init()
{
	var loc = location.href;
	
	var hashIndex = loc.indexOf('#preview_');
	
	if(hashIndex >= 0)
	{
		var hash = loc.substring(hashIndex + 9);
		
		if(deviceExists(hash))
		{
			viewPreview(hash);
		}
	}
	
}
function viewPreview(device)
{
	$('preview_' + device + '_frame').src = 'http://www.jappit.com/m/mobilejoomla/empty.html';
	
	startLoading($('preview_' + device + '_frame'));
	
	location.hash = 'preview_' + device;
	
	showDevice(device);
	
	$('preview_' + device + '_frame').onload = function()
	{
		stopLoading($('preview_' + device + '_frame'));
	};
	
	$('preview_' + device + '_frame').src = 'proxy.php?d=' + encodeURIComponent(device);
}
function deviceExists(name)
{
	for(var i = 0; i < devices.length; i++)
	{
		if(devices[i] == name)
		{
			return true;
		}
	}
	return false;
}
function showDevice(device)
{
	if(shownDevice != device)
	{
		//$('preview_' + shownDevice).style.display = 'none';
		
		$('preview_' + device).style.left = '480px';
		
		new Fx.Tween($('preview_' + shownDevice)).start('left', '0px', '480px').onComplete = function()
		{
			setCurrentDevice(device);
		}
	}
}
function setCurrentDevice(device)
{
	$('preview_' + shownDevice).style.display = 'none';
	
	shownDevice = device;
	
	$('preview_' + device).style.display = '';
	
	new Fx.Tween($('preview_' + device)).start('left', '480px', '0px');
}
function frameLoaded(device)
{
	stopLoading($('preview_' + device + '_frame'));
	
	$('preview_' + device + '_screenshot').style.display = '';
}
function startLoading(frame)
{
	frame.style.backgroundImage = 'url("images/ajax-loader.gif")';
}
function stopLoading(frame)
{
	frame.style.backgroundImage = '';
}