This application does not support back upping.

FlashSMS sender is used for sending type 0 SMS messages that are opened directly when received, also FlashSMS messages are not saved automatically in the receiving end.

To make a new FlashSMS message, type the message to be included in the Flash SMS, note that for normal SMS characters the message can be 160 characters long, and for other the message will be truncated to 70 characters.

Recipients can be added from contacts or by specifying the recipients number, both options are available in menu. Note that each message can have multiple recipients.

After the recipient(s) are defined and the message body written, you can send then message with send option from the menu.



 

