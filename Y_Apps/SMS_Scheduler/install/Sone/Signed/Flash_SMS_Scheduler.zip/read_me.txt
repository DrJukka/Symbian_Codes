
Note that this application does not support back upping.


This application is used for scheduling normal as well as Flash SMS messages with time. The length of the SMS is limited to 160 characters and 70 characters with Unicode encoded messages. Unicode encoding is used automatically when needed.

Flash messages are Class 0 SMS messages that are shown automatically in the receiving end, and only saved to the device if the receiver decides so.

To make a new scheduled message click new options from the menu. After there are messages in the schedule list you can use Enable/Disable menu for enabling/disabling the schedule. Modify option can be used for modifying the message, and delete option can be used for deleting it.

The actual scheduling of the SMS messages is handled by background server that is running if there are any schedules available that is also enabled.

The background application is also started automatically when device is started. Note that all settings and schedule changes are taking effect only after exiting the UI application.

With timer scheduled SMS messages, you only need to define the contact number, message and the time when the message is to be sent.

You can select the contact from the device's contacts list with menu options or by typing it directly with the settings item.

For the messages you could use the message store to save messages to be used later, or you can type the message with the settings item. The type settings defined whether the SMS message is normal SMS message or Flash SMS message.

The time for schedule can be selected with time settings item, the Repeat settings item allows the scheduling to be done on selected day on as repeating ones with specified repeat interval.

Note that repeated Schedules are not deleted from the schedule list, whereas the schedules specified for a specific date only, will be deleted from the scheduling database after the message is sent.






 

