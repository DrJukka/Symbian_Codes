This application does not support back upping.


This application is used for a screensaver type clock screen that is on while the devices keyboard is locked by the devices standard key lock. 
The lock's light will be illuminated if enabled after a device key is pressed (allowed keys are arrow left/right and menu key).

The lock screen is handled by background server that is running if either the clock screen or the key lock is set to be on. 
The background application is also started automatically when device is started. Note that settings are taking effect only after exiting the UI application.

Lights intensity settings are used to set the light intensity values that are used when key is pressed to show the clock screen. 
Charging light intensity is used when the device is charging. Light timeout settings specifies the time the lights are on after pressing the key, 
note that some devices ignore the value, and use the device lights out time value instead.

With lights on setting allows defining when the lights are on. The font setting can be used to select the font used with the clock display, 
as well as with the font color setting the text color can be changed. 

The background setting defines which background color is used with the clock screen.

The show date settings options allows disabling the date/day display on the top of the clock screen. 
The key lock settings item enables the background applications automatic key locking feature, 
and the lock after time values defines the required user inactivity time before the keyboard is locked.
