This application does not support back upping.


This application is designed to provide multi alarm with repeat options to those devices that does not nativly implement this functionality.

New alarm can be made with new option, and in the opening UI you can set the repeat option, time and the message for the alarm. The alarm type defines which alarm sound is played for the alarm. Click Done to save the alarm.

Reset option can then be used for resetting alarm details, remove option to remove the alarm and Enable/Disable options can be used for temporarily disabling the alarm.

With Set Alarm sounds option the alarm sound files can be set. The snooze settings define the snooze time in minutes, note that some devices ignore the snooze setting and use the default value instead.

With set workdays the device wide workdays settings can be modified, these settings are defining which days the alarms set for workdays will be active.




 

