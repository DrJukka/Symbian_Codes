
Note that this application does not support back upping.


This application is used for scheduling themes and wallpapers with timer or by profile change events, 
for each event type there is a menu option under the new menu item in the options menu, 
and new schedule can be made by selecting appropriate menu option.

To make a scheduler, first select either theme or wallpaper to be scheduled, and then select time and repeat options, 
or the profile which with the schedule is supposed to work with. Once done, save the schedule with save command. 

With random theme option the theme is picked randomly during the scheduling event, and if no theme is selected in the random theme list, 
all available themes will be used.

After the schedule is made it will be shown in the main view list. 

Within this list you can use menu options for opening the schedule for modifications as well as you can delete them, 
also temporal disabling/enabling menu options can be found from the options menu.

Note that theme are scheduled as well as previous schedules are re-freshed only after exiting the application. For best usability, 
each schedule should be spaced two minutes apart from each other. 

The actual scheduling is handled by background application that is also automatically started when the device is started. 

No message scheduling will appear while the device is off.


 

