Note that this application does not support back upping.


--------------- main appplication ------------------

This application is file manager that implements the most used options for normal file management. 
The file management options can be chosen from the options menu and the menu will usually hide any options that are currently not available.

File menu has options for showing and modifying file attributes, showing the file properties, deleting, 
renaming and making new files and folders. Also the show filename options allows showing and copying the filename to the clipboard.

Mark menu includes options for marking files for copy, cut, delete etc. options. Edit menu has the actual copy, 
cut and paste options as well as you can see the currently copy/cut selected files from its menu options.

Extras menu options are including additional options, such as shortcut management, 
note that shortcuts do require keypad with number input as well as ctrl key to be available at the device.

Search files menu option will open a file searching view from which you can set multiple options for file searching.

Settings menu option will open settings view, where General settings are used for handling general settings of the application, 
with Command shorts cuts a shortcut number for available commands can be set (note that this required the device to have number keypad present).

File association settings allows modifying the file handler applications for different mime types (works only internally) 
and with the plug-ins settings different plug-ins can be disabled/enabled as well as some settings for the plug-ins can be modified.


--------------- BT Sender ------------------

This plug-in is used to send files over Bluetooth OBEX service. The sending process is started automatically when the plug-in is started.

Just select the device you want to send the selected file(s) and they will be sent one-by-one. You can cancel the sending anytime by 
clicking the right soft key.

To start the sending process again, select Re-Send menu option.


--------------- Mail folders ------------------

This plug-in is used to help accessing files attached to messages, thus only attachments are shown in it.

Note that email attachments are often shown even when they are not downloaded, thus check the file size to see if they are actually 
just empty stub files.

Open option will try opening the attachment file with any application that is handling the file type of the selected file. 
And with copy option you can copy the file to the normal folders.

--------------- Text viewer  ------------------

This plug-in is used to show file content in text mode. Files are opened by default in ASCII mode, 
but you can specify other text formats by issuing Re-Read command from the options menu.

ASCII option will show the text as ASCII, Unicode as 16-bit Unicode text, and Hex as hexadecimal values. 
The select converter option will allow reading any file formats that are supported by the device.


---------------  Zip Plug-in ------------------


This plug-in is used for zipping and unzipping pkzip formatted zip files. 
You can make new zip file by selecting the new file from the main applications options menu. Existing zip files can be opened by clicking them.

When making a new file, you need to add files by selecting them and then selecting the menu option for adding them into the selection. 
When all needed files are selected, add them into the zip by selecting the option from the options menu.

File inside existing zip files can be extracted by selecting the extract menu option from the menu, 
and then selecting the folder to which the files are going to be extracted.


---------------  ------------------



---------------  ------------------

