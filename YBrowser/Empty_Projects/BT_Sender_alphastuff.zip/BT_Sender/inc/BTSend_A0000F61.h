/*
	Copyright (C) 2006 Jukka Silvennoinen
	All right reserved
*/

#ifndef __YUCCATOOLS_BASICAPPSTUFF_H__
#define __YUCCATOOLS_BASICAPPSTUFF_H__

#include <aknappui.h>
#include <aknapp.h>
#include <akndoc.h>
#include <aknwaitdialog.h> 
#include <AknProgressDialog.h>
#include <EIKPROGI.H>
#include <akncommondialogs.h> 
#include <maknfilefilter.h> 
#include <aknlists.h> 
#include <eikclbd.h>
#include <coecntrl.h>

#include "Public_Interfaces.h"

/*
----------------------------------------------
this will be eventually put in Public_Interfaces.h, but gotta get it 
updated completely first, so now just showing it in here..
*/
	class CYBrowserFileSender : public CCoeControl
	{	
	public: // default constructors	
		virtual void SetUtils(MYBrowserFileHandlerUtils* aExitHandler) = 0;
		virtual void ConstructL() = 0;
		// sender function
		virtual void SendFilesL(MDesCArray& aFileArray) = 0;
		// activate/deactivate handler
		virtual void SetFocusL(TBool aFocus) = 0;
		// commands handling
		virtual void DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane) = 0;
    	virtual void HandleCommandL(TInt aCommand) = 0;
    public:
		TUid iDestructorIDKey;
	};
/*
----------------------------------------------
*/	

	class  CMyFileSender : public CYBrowserFileSender,MProgressDialogCallback
	{	
	public: 
		~CMyFileSender();
		// default constructors	
		void SetUtils(MYBrowserFileHandlerUtils* aFileHandlerUtils);
		void ConstructL();
	public:
		// handler settings and support
		void SendFilesL(MDesCArray& aFileArray);
		// activate/deactivate handler
		void SetFocusL(TBool aFocus);
		// commands handling
		void DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane);
    	void HandleCommandL(TInt aCommand);
    protected://
    	void DialogDismissedL (TInt aButtonId);
    private:
    	// functions from CCoeControl, called by Y-Browser
    	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
	private:// own functions for operations
		void SetMenuL(void);
		void Draw(const TRect& aRect) const;
		virtual void SizeChanged();
	private:	
		MYBrowserFileHandlerUtils* 	iFileHandlerUtils;
		TInt						iResId;
		CAknProgressDialog* 		iProgressDialog;
		CEikProgressInfo* 			iProgressInfo;
		CDesCArrayFlat* 			iSendFilesList;
	};


#endif // __YUCCATOOLS_BASICAPPSTUFF_H__

