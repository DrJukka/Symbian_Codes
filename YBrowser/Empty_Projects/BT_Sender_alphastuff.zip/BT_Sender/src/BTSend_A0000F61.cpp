/*
	Copyright (C) 2006 Jukka Silvennoinen
	All right reserved
*/

// INCLUDE FILES
#include <avkon.hrh>
#include <APPARC.H>
#include <aknnotewrappers.h>
#include <stringloader.h>
#include <aknnotewrappers.h>
#include <BAUTILS.H> 
#include <ecom.h>
#include <implementationproxy.h>
#include <aknmessagequerydialog.h> 
#include <akniconarray.h> 
#include <akntitle.h> 
#include <akncontext.h> 
#include <TXTRICH.H>
#include <CHARCONV.H>
#include <eikmenub.h> 

#include "BTSend_A0000F61.h"
#include "BTSend_A0000F61.hrh"

#include "BTSend_A0000F61_res.rsg"

#include <eikstart.h>


// I have usually put images under common folder like this
// anyway, it is up to the developer to decide where to put them
_LIT(KMyImageFileName		,"\\\\system\\data\\A00007A6\\A0000F61\\Images.mbm");	

// own resource file
_LIT(KMyResourceFileName	,"\\resource\\apps\\BTSend_A0000F61_res.RSC");

_LIT(KtxApplicationName		,"BT Sender");
_LIT(KtxAbbout				,"version 0.80\nJanuary 14th 2007\nfor S60, Symbian OS 9,\n\nCopyright:\nJukka Silvennoinen 2006\nAll right reserved.\n\nemail:\nsymbianyucca@gmail.com\nHomepage:\nwww.pushl.com/y_browser/");
	
/*
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
*/
CMyFileSender::~CMyFileSender()
{
	if(iProgressDialog)
	{
		iProgressDialog->ProcessFinishedL(); 
	}

	iProgressDialog = NULL;
	iProgressInfo = NULL;
		
	if(iResId > 0)
	{
		CEikonEnv::Static()->DeleteResourceFile(iResId);
	}
	
	delete iSendFilesList;
	
	// do not remove.. needed for ECOM
	REComSession::DestroyedImplementation(iDestructorIDKey);
}
/*
-------------------------------------------------------------------------
this will be called right after first constructor has finished
there shouldn't be any need to chnage this one.
-------------------------------------------------------------------------
*/
void CMyFileSender::SetUtils(MYBrowserFileHandlerUtils* aFileHandlerUtils)
{
	// some utilities provided by Y-Browser
	// I will re-design this a bit and add some stuff
	// might also change function definitions
	// could do with feedback on requirements !!
	iFileHandlerUtils = aFileHandlerUtils;
}

/*
-------------------------------------------------------------------------
This will be called when this file shandler is preraped to be used for, 
opening or constructing a file. The open/new etc. functions are called
strait after calling this function.
-------------------------------------------------------------------------
*/
void CMyFileSender::ConstructL()
{
 	CreateWindowL();
 	
 	iResId = -1;
 	TFindFile AppFile(CCoeEnv::Static()->FsSession());
	if(KErrNone == AppFile.FindByDir(KMyResourceFileName, KNullDesC))
	{
 		TFileName resourceName(AppFile.File());
		BaflUtils::NearestLanguageFile(CEikonEnv::Static()->FsSession(), resourceName);
		iResId = CEikonEnv::Static()->AddResourceFileL(resourceName);
	}

	
	SetRect(CEikonEnv::Static()->EikAppUi()->ClientRect()); 	
	
	// if you don't want to see the path in there, 
	// then just set it to empty
	iFileHandlerUtils->GetFileUtils().SetNaviTextL(_L(""));	
	
 	ActivateL();
	SetMenuL();
}

/*
-----------------------------------------------------------------------------
Y-Browser will call setsize for client rect when lay-out or size changes,
This will be then called by the framework
-----------------------------------------------------------------------------
*/
void CMyFileSender::SizeChanged()
{
	// re-size controls if necessary
}

/*
-------------------------------------------------------------------------
Y-Browser will call this when focus changes.

i.e. When you ask y-browser to open a file, and it will be opened by
other y-browser handler, then you will be called with focus false, 
right before new handler takes focus. Also (maybe) in future editions
this will be called (with ETrue) when file selection (add files) is cancelled

Also called with ETrue, when focus chnages back from other handlers.

-------------------------------------------------------------------------
*/
void CMyFileSender::SetFocusL(TBool aFocus)
{

	if(aFocus)
	{
		CEikStatusPane*		sp = ((CAknAppUi*)iEikonEnv->EikAppUi())->StatusPane();
		if(sp)
		{
			CAknTitlePane* TitlePane = STATIC_CAST(CAknTitlePane*,sp->ControlL(TUid::Uid(EEikStatusPaneUidTitle)));
			TitlePane->SetTextL(KtxApplicationName);
				
	   /* 	// if there would be icons could set them in here..
	   		CAknContextPane* 	ContextPane = (CAknContextPane *)sp->ControlL(TUid::Uid(EEikStatusPaneUidContext));
			if(ContextPane)
			{
				TFindFile AppFile(CCoeEnv::Static()->FsSession());
				if(KErrNone == AppFile.FindByDir(KtxIconsFileName, KNullDesC))
				{
					ContextPane->SetPictureFromFileL(AppFile.File(),EMbmIconsB,EMbmIconsB_m);  
				}
			}				
	*/	}		
	
		SetMenuL();
		DrawNow();	
	}
}
/*
-------------------------------------------------------------------------
internal function for updating menu and CBA's for the application
-------------------------------------------------------------------------
*/
void CMyFileSender::SetMenuL(void)
{
	// set own menu & CBA.

	if(iFileHandlerUtils)
	{
		iFileHandlerUtils->GetCba().SetCommandSetL(R_MAIN_CBA);				
		iFileHandlerUtils->GetCba().DrawDeferred();
	}
	
	CEikonEnv::Static()->AppUiFactory()->MenuBar()->SetMenuTitleResourceId(R_MAIN_MENUBAR);	
}
/*
-------------------------------------------------------------------------
Normal DynInitMenuPaneL, which Y-Browser will call.

See SDK documentation for more information
-------------------------------------------------------------------------
*/
void CMyFileSender::DynInitMenuPaneL(TInt /*aResourceId*/, CEikMenuPane* /*aMenuPane*/)
{

}

/*
-------------------------------------------------------------------------
This is the function where Y-Browser gives the file array for sending.
Called after ConstructL, it is advised to copy the array, just to be
on safe side
-------------------------------------------------------------------------
*/
void CMyFileSender::SendFilesL(MDesCArray& aFileArray)
{	
	if(aFileArray.MdcaCount())
	{
		delete iSendFilesList;
		iSendFilesList = NULL;
		iSendFilesList = new(ELeave)CDesCArrayFlat(aFileArray.MdcaCount());
		
		for(TInt i=0; i < aFileArray.MdcaCount(); i++)
		{
			iSendFilesList->AppendL(aFileArray.MdcaPoint(i));
		}

		iProgressDialog = new (ELeave) CAknProgressDialog((REINTERPRET_CAST(CEikDialog**,&iProgressDialog)),ETrue);
		iProgressDialog->PrepareLC(R_PROGRESS_NOTE);
		iProgressInfo = iProgressDialog->GetProgressInfoL();
		iProgressDialog->SetCallback(this);
		iProgressDialog->RunLD();
		iProgressInfo->SetFinalValue((aFileArray.MdcaCount() + 1));
	
		//Start the process...
		// have a callback function where you could update 
		// the progress note accordingly
		
		// and when finished you could show Global note 
		// and then just call HandleCommandL(EBacktoYBrowser);
	}
	else
	{
		HandleCommandL(EBacktoYBrowser);
	}
}
/*
-------------------------------------------------------------------------
Handle command called by Y-Browser,make sure you set your menu & CBA's 
when focus changes, and that your commands are started at least with
first command as 0x7000.

-------------------------------------------------------------------------
*/

void CMyFileSender::HandleCommandL(TInt aCommand)
{
	switch (aCommand)
    { 
    case EAbout:
    	{
    		HBufC* Abbout = KtxAbbout().AllocLC();
			TPtr Pointter(Abbout->Des());
			CAknMessageQueryDialog* dlg = CAknMessageQueryDialog::NewL(Pointter);
			dlg->PrepareLC(R_ABOUT_HEADING_PANE);
			dlg->SetHeaderTextL(KtxApplicationName);  
			dlg->RunLD();
			
			CleanupStack::PopAndDestroy(Abbout);
    	}
    	break;
    case EBacktoYBrowser:
    	if(iFileHandlerUtils)
    	{
    		// I'll update this function later
    		// i needs a TInt identifier added to it.
    		iFileHandlerUtils->HandleExitL(this);	
    	}
    	break; 
	default:
		break;
    };
}


/*
-----------------------------------------------------------------------
normal implementation of the OfferKeyEventL, called  by Y-Browser when 
in focus

See SDK documentations for more information
-----------------------------------------------------------------------
*/
TKeyResponse CMyFileSender::OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode /*aType*/)
{
	TKeyResponse Ret = EKeyWasNotConsumed;
	
	switch (aKeyEvent.iCode)
    {
	case EKeyDevice3:
	//	CEikonEnv::Static()->AppUiFactory()->MenuBar()->TryDisplayMenuBarL();
		break;
	case EKeyUpArrow:
	case EKeyDownArrow:
	default:
		break;
    };
    
	return Ret;
}
/*
-----------------------------------------------------------------------
just normal Draw

See SDK documentations for more information
-----------------------------------------------------------------------
*/
void CMyFileSender::Draw(const TRect& aRect) const
{
 	CWindowGc& gc = SystemGc();
 	gc.Clear(aRect);
 	
 	//should Draw a Nice background image in here...
}

/*
-----------------------------------------------------------------------------
normal MProgressDialogCallback callback function.

See SDK documentations for more information
----------------------------------------------------------------------------
*/
void CMyFileSender::DialogDismissedL (TInt /*aButtonId*/)
{		  		
	iProgressDialog = NULL;
	iProgressInfo = NULL;
	
// should propably call HandleCommandL(EBacktoYBrowser);
}


/*
-------------------------------------------------------------------------
interface function for getting the implementation instance
-------------------------------------------------------------------------
*/
CYBrowserFileSender* NewFileSender()
    {
    return (new CMyFileSender);
    }
/*
-------------------------------------------------------------------------
ECOM ImplementationTable function

See SDK documentations for more information
-------------------------------------------------------------------------
*/

LOCAL_D const TImplementationProxy ImplementationTable[] = 
{
	IMPLEMENTATION_PROXY_ENTRY(0x0F61,NewFileSender)
};


/*
-------------------------------------------------------------------------
ECom ImplementationGroupProxy function

See SDK documentations for more information
-------------------------------------------------------------------------
*/
EXPORT_C const TImplementationProxy* ImplementationGroupProxy(TInt& aTableCount)
{
	aTableCount = sizeof(ImplementationTable)/sizeof(ImplementationTable[0]);
	return ImplementationTable;
}

